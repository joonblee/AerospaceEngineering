function [SFD] = GetSFD(SFD,xipos,etapos)
%% compute shape function derivatives

%  Coded by Prof. Gun Jin Yun (gunjin.yun@snu.ac.kr)
%  May 15 17 2017
%  Computational Structural Analysis Spring 2017

% xi-derivatives d_N/d_xi


% eta-derivative d_N/d_eta

return