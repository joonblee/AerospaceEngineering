function SetGaussQ(ngaus)
%% set Gauss quadrature constants

%  Coded by Prof. Gun Jin Yun (gunjin.yun@snu.ac.kr)
%  May 15 17 2017
%  Computational Structural Analysis Spring 2017

global posgp weigp

% initialize variables
posgp = zeros(ngaus*ngaus,2);
weigp = zeros(ngaus*ngaus,2);


return